import React, { useState } from "react";
import Camera from "../components/camera";
import AttendanceLogger from "../components/attendancelogger";

const Home = () => {
  const [attendance, setAttendance] = useState([]);

  const handleFaceDetected = (predictions) => {
    if (predictions.length > 0) {
      const timestamp = new Date().toLocaleString();
      setAttendance((prev) => [
        ...prev,
        { timestamp, status: "Logged In" },
      ]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center p-8">
      <h1 className="text-2xl font-bold mb-4">Facial Recognition Attendance</h1>
      <div className="w-full max-w-2xl">
        <Camera onFaceDetected={handleFaceDetected} />
        <AttendanceLogger attendance={attendance} />
      </div>
    </div>
  );
};

export default Home;
