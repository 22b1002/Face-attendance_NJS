import React, { useRef, useEffect } from "react";
import * as blazeface from "@tensorflow-models/blazeface";
import "@tensorflow/tfjs";

const Camera = ({ onFaceDetected }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  useEffect(() => {
    const setupCamera = async () => {
      try {
        // Load the BlazeFace model
        const model = await blazeface.load();

        // Get access to the camera
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
        });

        // Attach the stream to the video element
        videoRef.current.srcObject = stream;
        videoRef.current.play();

        videoRef.current.addEventListener("loadeddata", () => {
          console.log("Video loaded and playing.");
          startFaceDetection(model);
        });
      } catch (error) {
        console.error("Error setting up the camera:", error);
      }
    };

    const startFaceDetection = (model) => {
      const detectFaces = async () => {
        if (videoRef.current && videoRef.current.readyState === 4) {
          const predictions = await model.estimateFaces(videoRef.current, false);
          if (predictions.length > 0) {
            console.log("Face detected:", predictions);
            drawPredictions(predictions);
            onFaceDetected(predictions);
          }
        }
      };

      // Run face detection at regular intervals
      setInterval(detectFaces, 100);
    };

    const drawPredictions = (predictions) => {
      const canvas = canvasRef.current;
      const context = canvas.getContext("2d");
      const video = videoRef.current;

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      context.clearRect(0, 0, canvas.width, canvas.height);

      predictions.forEach((prediction) => {
        const [x, y, width, height] = prediction.topLeft.concat(
          prediction.bottomRight.map((val, index) => val - prediction.topLeft[index])
        );

        // Draw bounding box
        context.strokeStyle = "red";
        context.lineWidth = 2;
        context.strokeRect(x, y, width, height);

        // Draw label
        context.font = "16px Arial";
        context.fillStyle = "red";
        context.fillText("Face", x, y - 10);
      });
    };

    setupCamera();
  }, [onFaceDetected]);

  return (
    <div style={{ position: "relative" }}>
      {/* Video element */}
      <video
        ref={videoRef}
        style={{
          width: "100%",
          height: "auto",
          border: "2px solid black",
        }}
        playsInline
        autoPlay
        muted
      />

      {/* Canvas overlay for predictions */}
      <canvas
        ref={canvasRef}
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          pointerEvents: "none",
        }}
      />
    </div>
  );
};

export default Camera;

