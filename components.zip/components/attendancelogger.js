import React from "react";

const AttendanceLogger = ({ attendance }) => {
  return (
    <div className="bg-gray-100 p-4 rounded-lg shadow-md">
      <h2 className="text-lg font-bold">Attendance Log</h2>
      <ul>
        {attendance.map((entry, index) => (
          <li key={index} className="mt-2">
            {entry.timestamp} - {entry.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AttendanceLogger;
